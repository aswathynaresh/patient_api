package com.ehealth.gov;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GovApplicationTests {

	@Test
	void contextLoads() {
	}

}
